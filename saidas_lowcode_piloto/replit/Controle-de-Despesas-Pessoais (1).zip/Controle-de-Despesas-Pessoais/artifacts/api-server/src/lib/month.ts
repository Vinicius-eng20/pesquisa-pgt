export function resolveMonth(month?: string): string | null {
  if (!month) {
    return new Date().toISOString().slice(0, 7);
  }
  const match = /^(\d{4})-(\d{2})$/.exec(month);
  if (!match) {
    return null;
  }
  const numericMonth = Number(match[2]);
  return numericMonth >= 1 && numericMonth <= 12 ? month : null;
}

export function monthBounds(month: string): { start: string; end: string } {
  const [year, monthNumber] = month.split("-").map(Number);
  const end = new Date(Date.UTC(year, monthNumber, 1))
    .toISOString()
    .slice(0, 10);
  return { start: `${month}-01`, end };
}
