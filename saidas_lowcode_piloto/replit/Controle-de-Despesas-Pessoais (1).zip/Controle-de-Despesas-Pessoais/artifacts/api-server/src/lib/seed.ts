import { categoriesTable, db } from "@workspace/db";

const initialCategories = [
  "Alimentação",
  "Moradia",
  "Transporte",
  "Saúde",
  "Educação",
  "Lazer",
  "Contas",
  "Outros",
];

export async function seedCategories(): Promise<void> {
  await db
    .insert(categoriesTable)
    .values(initialCategories.map((name) => ({ name })))
    .onConflictDoNothing();
}
