import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import type { RequestHandler } from "express";
import { and, eq, gt } from "drizzle-orm";
import { db, sessionsTable, usersTable } from "@workspace/db";

export type PublicUser = Pick<
  typeof usersTable.$inferSelect,
  "id" | "name" | "email" | "role" | "isActive"
>;

declare global {
  namespace Express {
    interface Request {
      user?: PublicUser;
      sessionToken?: string;
    }
  }
}

const SESSION_COOKIE = "expense_session";
const SESSION_LIFETIME_MS = 30 * 24 * 60 * 60 * 1000;

function hashSessionToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: SESSION_LIFETIME_MS,
  };
}

export function setSessionCookie(res: Parameters<RequestHandler>[1], token: string): void {
  res.cookie(SESSION_COOKIE, token, cookieOptions());
}

export function clearSessionCookie(res: Parameters<RequestHandler>[1]): void {
  res.clearCookie(SESSION_COOKIE, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
  });
}

export async function createSession(userId: number, res: Parameters<RequestHandler>[1]): Promise<void> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_LIFETIME_MS);
  await db.insert(sessionsTable).values({
    userId,
    tokenHash: hashSessionToken(token),
    expiresAt,
  });
  setSessionCookie(res, token);
}

export async function revokeSession(token: string): Promise<void> {
  await db
    .delete(sessionsTable)
    .where(eq(sessionsTable.tokenHash, hashSessionToken(token)));
}

export async function getSessionUser(
  req: Parameters<RequestHandler>[0],
  res: Parameters<RequestHandler>[1],
): Promise<PublicUser | null> {
  const token = req.cookies?.[SESSION_COOKIE];
  if (typeof token !== "string") {
    return null;
  }
  if (!/^[a-f0-9]{64}$/.test(token)) {
    clearSessionCookie(res);
    return null;
  }

  const [session] = await db
    .select({
      tokenHash: sessionsTable.tokenHash,
      userId: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
      isActive: usersTable.isActive,
    })
    .from(sessionsTable)
    .innerJoin(usersTable, eq(usersTable.id, sessionsTable.userId))
    .where(
      and(
        eq(sessionsTable.tokenHash, hashSessionToken(token)),
        gt(sessionsTable.expiresAt, new Date()),
      ),
    )
    .limit(1);

  if (!session || !session.isActive) {
    await revokeSession(token);
    clearSessionCookie(res);
    return null;
  }

  req.user = {
    id: session.userId,
    name: session.name,
    email: session.email,
    role: session.role,
    isActive: session.isActive,
  };
  req.sessionToken = token;
  return req.user;
}

export const requireUser: RequestHandler = async (req, res, next) => {
  const user = await getSessionUser(req, res);
  if (!user) {
    res.status(401).json({ error: "Entre na sua conta para continuar." });
    return;
  }
  next();
};

export const requireAdmin: RequestHandler = (req, res, next) => {
  if (!req.user) {
    res.status(401).json({ error: "Entre na sua conta para continuar." });
    return;
  }
  if (req.user.role !== "admin") {
    res.status(403).json({ error: "Acesso exclusivo do administrador." });
    return;
  }
  next();
};

export function toPublicUser(user: PublicUser) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    isActive: user.isActive,
  };
}

export function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  return new Promise((resolve, reject) => {
    scrypt(password, salt, 64, (error, derivedKey) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(`${salt}:${derivedKey.toString("hex")}`);
    });
  });
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [salt, storedHex] = stored.split(":");
  if (!salt || !storedHex || !/^[a-f0-9]{128}$/.test(storedHex)) {
    return false;
  }
  const actual = await new Promise<Buffer>((resolve, reject) => {
    scrypt(password, salt, 64, (error, derivedKey) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(derivedKey as Buffer);
    });
  });
  const expected = Buffer.from(storedHex, "hex");
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
