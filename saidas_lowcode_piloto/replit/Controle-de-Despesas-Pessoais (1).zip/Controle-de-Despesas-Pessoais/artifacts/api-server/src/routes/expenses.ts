import { Router, type IRouter } from "express";
import {
  and,
  asc,
  count,
  desc,
  eq,
  gte,
  lt,
  sql,
  type SQL,
} from "drizzle-orm";
import {
  categoriesTable,
  db,
  expensesTable,
  usersTable,
} from "@workspace/db";
import {
  CreateExpenseBody,
  CreateExpenseResponse,
  DeleteExpenseParams,
  GetDashboardQueryParams,
  GetDashboardResponse,
  ListCategoriesResponse,
  ListExpensesQueryParams,
  ListExpensesResponse,
  UpdateExpenseBody,
  UpdateExpenseParams,
  UpdateExpenseResponse,
} from "@workspace/api-zod";
import { requireUser } from "../lib/auth";
import { monthBounds, resolveMonth } from "../lib/month";

const router: IRouter = Router();

function expenseConditions(
  userId: number,
  start?: string,
  end?: string,
): SQL[] {
  const conditions: SQL[] = [eq(expensesTable.userId, userId)];
  if (start && end) {
    conditions.push(gte(expensesTable.spentAt, start), lt(expensesTable.spentAt, end));
  }
  return conditions;
}

async function categoryTotals(
  userId: number,
  start: string,
  end: string,
) {
  const rows = await db
    .select({
      categoryId: categoriesTable.id,
      categoryName: categoriesTable.name,
      totalCents: sql<number>`coalesce(sum(${expensesTable.amountCents}), 0)`,
      count: count(),
    })
    .from(expensesTable)
    .innerJoin(categoriesTable, eq(categoriesTable.id, expensesTable.categoryId))
    .where(and(...expenseConditions(userId, start, end)))
    .groupBy(categoriesTable.id, categoriesTable.name)
    .orderBy(desc(sql`sum(${expensesTable.amountCents})`));

  return rows.map((row) => ({
    categoryId: row.categoryId,
    categoryName: row.categoryName,
    totalCents: Number(row.totalCents),
    count: Number(row.count),
  }));
}

async function expensesForUser(
  userId: number,
  start?: string,
  end?: string,
  categoryId?: number,
) {
  const conditions = expenseConditions(userId, start, end);
  if (categoryId !== undefined) {
    conditions.push(eq(expensesTable.categoryId, categoryId));
  }
  const rows = await db
    .select({
      id: expensesTable.id,
      categoryId: expensesTable.categoryId,
      categoryName: categoriesTable.name,
      amountCents: expensesTable.amountCents,
      spentAt: expensesTable.spentAt,
      description: expensesTable.description,
      createdAt: expensesTable.createdAt,
    })
    .from(expensesTable)
    .innerJoin(categoriesTable, eq(categoriesTable.id, expensesTable.categoryId))
    .where(and(...conditions))
    .orderBy(desc(expensesTable.spentAt), desc(expensesTable.createdAt));
  return rows;
}

router.get("/categories", requireUser, async (req, res): Promise<void> => {
  const categories = await db
    .select()
    .from(categoriesTable)
    .where(req.user?.role === "admin" ? undefined : eq(categoriesTable.isActive, true))
    .orderBy(asc(categoriesTable.name));
  res.json(ListCategoriesResponse.parse(categories));
});

router.get("/expenses", requireUser, async (req, res): Promise<void> => {
  const parsed = ListExpensesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const month = parsed.data.month
    ? resolveMonth(parsed.data.month)
    : undefined;
  if (parsed.data.month && !month) {
    res.status(400).json({ error: "O mês informado é inválido." });
    return;
  }
  const bounds = month ? monthBounds(month) : undefined;
  const expenses = await expensesForUser(
    req.user!.id,
    bounds?.start,
    bounds?.end,
    parsed.data.categoryId,
  );
  res.json(ListExpensesResponse.parse(expenses));
});

router.post("/expenses", requireUser, async (req, res): Promise<void> => {
  const parsed = CreateExpenseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [category] = await db
    .select()
    .from(categoriesTable)
    .where(
      and(
        eq(categoriesTable.id, parsed.data.categoryId),
        eq(categoriesTable.isActive, true),
      ),
    )
    .limit(1);
  if (!category) {
    res.status(400).json({ error: "Escolha uma categoria disponível." });
    return;
  }

  const [created] = await db
    .insert(expensesTable)
    .values({
      ...parsed.data,
      spentAt: parsed.data.spentAt.toISOString().slice(0, 10),
      userId: req.user!.id,
    })
    .returning();
  const expense = {
    ...created,
    categoryName: category.name,
  };
  res.status(201).json(CreateExpenseResponse.parse(expense));
});

router.patch("/expenses/:expenseId", requireUser, async (req, res): Promise<void> => {
  const params = UpdateExpenseParams.safeParse(req.params);
  const parsed = UpdateExpenseBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(expensesTable)
    .where(
      and(
        eq(expensesTable.id, params.data.expenseId),
        eq(expensesTable.userId, req.user!.id),
      ),
    )
    .limit(1);
  if (!existing) {
    res.status(404).json({ error: "Gasto não encontrado." });
    return;
  }

  const [category] = await db
    .select()
    .from(categoriesTable)
    .where(
      and(
        eq(categoriesTable.id, parsed.data.categoryId),
        existing.categoryId === parsed.data.categoryId
          ? undefined
          : eq(categoriesTable.isActive, true),
      ),
    )
    .limit(1);
  if (!category) {
    res.status(400).json({ error: "Escolha uma categoria disponível." });
    return;
  }

  const [updated] = await db
    .update(expensesTable)
    .set({
      ...parsed.data,
      spentAt: parsed.data.spentAt.toISOString().slice(0, 10),
    })
    .where(
      and(
        eq(expensesTable.id, params.data.expenseId),
        eq(expensesTable.userId, req.user!.id),
      ),
    )
    .returning();
  res.json(
    UpdateExpenseResponse.parse({
      ...updated,
      categoryName: category.name,
    }),
  );
});

router.delete("/expenses/:expenseId", requireUser, async (req, res): Promise<void> => {
  const params = DeleteExpenseParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(expensesTable)
    .where(
      and(
        eq(expensesTable.id, params.data.expenseId),
        eq(expensesTable.userId, req.user!.id),
      ),
    )
    .returning({ id: expensesTable.id });
  if (!deleted) {
    res.status(404).json({ error: "Gasto não encontrado." });
    return;
  }
  res.sendStatus(204);
});

router.get("/dashboard", requireUser, async (req, res): Promise<void> => {
  const parsed = GetDashboardQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const month = resolveMonth(parsed.data.month);
  if (!month) {
    res.status(400).json({ error: "O mês informado é inválido." });
    return;
  }
  const { start, end } = monthBounds(month);
  const conditions = expenseConditions(req.user!.id, start, end);
  const [totals] = await db
    .select({
      totalCents: sql<number>`coalesce(sum(${expensesTable.amountCents}), 0)`,
      expenseCount: count(),
    })
    .from(expensesTable)
    .where(and(...conditions));
  const categoryBreakdown = await categoryTotals(req.user!.id, start, end);
  const recentExpenses = await expensesForUser(req.user!.id, start, end);
  res.json(
    GetDashboardResponse.parse({
      month,
      totalCents: Number(totals.totalCents),
      expenseCount: Number(totals.expenseCount),
      categoryTotals: categoryBreakdown,
      recentExpenses: recentExpenses.slice(0, 5),
    }),
  );
});

export async function adminCategoryTotals(start: string, end: string) {
  const rows = await db
    .select({
      categoryId: categoriesTable.id,
      categoryName: categoriesTable.name,
      totalCents: sql<number>`coalesce(sum(${expensesTable.amountCents}), 0)`,
      count: count(),
    })
    .from(expensesTable)
    .innerJoin(categoriesTable, eq(categoriesTable.id, expensesTable.categoryId))
    .where(
      and(
        gte(expensesTable.spentAt, start),
        lt(expensesTable.spentAt, end),
      ),
    )
    .groupBy(categoriesTable.id, categoriesTable.name)
    .orderBy(desc(sql`sum(${expensesTable.amountCents})`));
  return rows.map((row) => ({
    categoryId: row.categoryId,
    categoryName: row.categoryName,
    totalCents: Number(row.totalCents),
    count: Number(row.count),
  }));
}

export async function allExpenseTotals(start: string, end: string) {
  const [totals] = await db
    .select({
      totalCents: sql<number>`coalesce(sum(${expensesTable.amountCents}), 0)`,
      expenseCount: count(),
    })
    .from(expensesTable)
    .where(and(gte(expensesTable.spentAt, start), lt(expensesTable.spentAt, end)));
  return {
    totalCents: Number(totals.totalCents),
    expenseCount: Number(totals.expenseCount),
  };
}

export async function userCounts() {
  const [counts] = await db
    .select({
      totalUsers: count(),
      activeUsers: sql<number>`count(*) filter (where ${usersTable.isActive} = true)`,
    })
    .from(usersTable);
  return {
    totalUsers: Number(counts.totalUsers),
    activeUsers: Number(counts.activeUsers),
  };
}

export default router;
