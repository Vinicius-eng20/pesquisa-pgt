import { Router, type IRouter } from "express";
import { and, asc, eq, sql } from "drizzle-orm";
import {
  categoriesTable,
  db,
  sessionsTable,
  usersTable,
} from "@workspace/db";
import {
  CreateCategoryBody,
  CreateCategoryResponse,
  GetAdminSummaryQueryParams,
  GetAdminSummaryResponse,
  ListUsersResponse,
  UpdateCategoryBody,
  UpdateCategoryParams,
  UpdateCategoryResponse,
  UpdateUserStatusBody,
  UpdateUserStatusParams,
  UpdateUserStatusResponse,
} from "@workspace/api-zod";
import { requireAdmin, requireUser } from "../lib/auth";
import { monthBounds, resolveMonth } from "../lib/month";
import {
  adminCategoryTotals,
  allExpenseTotals,
  userCounts,
} from "./expenses";

const router: IRouter = Router();

router.post(
  "/admin/categories",
  requireUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsed = CreateCategoryBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const name = parsed.data.name.trim();
    if (!name) {
      res.status(400).json({ error: "Informe o nome da categoria." });
      return;
    }
    const [existing] = await db
      .select({ id: categoriesTable.id })
      .from(categoriesTable)
      .where(sql`lower(${categoriesTable.name}) = ${name.toLowerCase()}`)
      .limit(1);
    if (existing) {
      res.status(409).json({ error: "Essa categoria já existe." });
      return;
    }
    const [category] = await db
      .insert(categoriesTable)
      .values({ name })
      .returning();
    res.status(201).json(CreateCategoryResponse.parse(category));
  },
);

router.patch(
  "/admin/categories/:categoryId",
  requireUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const params = UpdateCategoryParams.safeParse(req.params);
    const parsed = UpdateCategoryBody.safeParse(req.body);
    if (!params.success || !parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
      res.status(400).json({
        error: !params.success
          ? params.error.message
          : !parsed.success
            ? parsed.error.message
            : "Informe o que deve ser alterado.",
      });
      return;
    }
    const name = parsed.data.name?.trim();
    if (parsed.data.name !== undefined && !name) {
      res.status(400).json({ error: "Informe o nome da categoria." });
      return;
    }
    if (name) {
      const [duplicate] = await db
        .select({ id: categoriesTable.id })
        .from(categoriesTable)
        .where(
          and(
            sql`lower(${categoriesTable.name}) = ${name.toLowerCase()}`,
            sql`${categoriesTable.id} <> ${params.data.categoryId}`,
          ),
        )
        .limit(1);
      if (duplicate) {
        res.status(409).json({ error: "Essa categoria já existe." });
        return;
      }
    }

    const [category] = await db
      .update(categoriesTable)
      .set({
        ...(name ? { name } : {}),
        ...(parsed.data.isActive !== undefined
          ? { isActive: parsed.data.isActive }
          : {}),
      })
      .where(eq(categoriesTable.id, params.data.categoryId))
      .returning();
    if (!category) {
      res.status(404).json({ error: "Categoria não encontrada." });
      return;
    }
    res.json(UpdateCategoryResponse.parse(category));
  },
);

router.get(
  "/admin/summary",
  requireUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsed = GetAdminSummaryQueryParams.safeParse(req.query);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const month = resolveMonth(parsed.data.month);
    if (!month) {
      res.status(400).json({ error: "O mês informado é inválido." });
      return;
    }
    const { start, end } = monthBounds(month);
    const [spending, accounts, categories] = await Promise.all([
      allExpenseTotals(start, end),
      userCounts(),
      adminCategoryTotals(start, end),
    ]);
    res.json(
      GetAdminSummaryResponse.parse({
        month,
        ...spending,
        ...accounts,
        categoryTotals: categories,
      }),
    );
  },
);

router.get(
  "/admin/users",
  requireUser,
  requireAdmin,
  async (_req, res): Promise<void> => {
    const users = await db
      .select({
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        createdAt: usersTable.createdAt,
      })
      .from(usersTable)
      .orderBy(asc(usersTable.createdAt));
    res.json(ListUsersResponse.parse(users));
  },
);

router.patch(
  "/admin/users/:userId/status",
  requireUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const params = UpdateUserStatusParams.safeParse(req.params);
    const parsed = UpdateUserStatusBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    if (params.data.userId === req.user!.id) {
      res.status(403).json({ error: "Não é possível desativar a própria conta." });
      return;
    }

    const [target] = await db
      .select({ id: usersTable.id, role: usersTable.role })
      .from(usersTable)
      .where(eq(usersTable.id, params.data.userId))
      .limit(1);
    if (!target) {
      res.status(404).json({ error: "Conta não encontrada." });
      return;
    }
    if (target.role !== "user") {
      res.status(403).json({ error: "Contas de administrador não podem ser desativadas por aqui." });
      return;
    }

    const [user] = await db
      .update(usersTable)
      .set({ isActive: parsed.data.isActive })
      .where(eq(usersTable.id, params.data.userId))
      .returning({
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
        isActive: usersTable.isActive,
        createdAt: usersTable.createdAt,
      });
    if (!user) {
      res.status(404).json({ error: "Conta não encontrada." });
      return;
    }
    if (!user.isActive) {
      await db
        .delete(sessionsTable)
        .where(eq(sessionsTable.userId, user.id));
    }
    res.json(UpdateUserStatusResponse.parse(user));
  },
);

export default router;
