import { Router, type IRouter } from "express";
import { count, eq, sql } from "drizzle-orm";
import {
  db,
  sessionsTable,
  usersTable,
} from "@workspace/db";
import {
  GetCurrentUserResponse,
  LoginBody,
  LoginResponse,
  RegisterBody,
  RegisterResponse,
} from "@workspace/api-zod";
import {
  clearSessionCookie,
  createSession,
  getSessionUser,
  hashPassword,
  requireUser,
  revokeSession,
  toPublicUser,
  verifyPassword,
} from "../lib/auth";

const router: IRouter = Router();

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const name = parsed.data.name.trim();
  const email = parsed.data.email.trim().toLowerCase();
  if (!name) {
    res.status(400).json({ error: "Informe seu nome." });
    return;
  }

  const passwordHash = await hashPassword(parsed.data.password);
  let user: typeof usersTable.$inferSelect;
  try {
    user = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(6652301)`);
      const [accountCount] = await tx.select({ value: count() }).from(usersTable);
      const role = accountCount.value === 0 ? "admin" : "user";
      const [created] = await tx
        .insert(usersTable)
        .values({ name, email, passwordHash, role })
        .returning();
      return created;
    });
  } catch (error) {
    if (
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      error.code === "23505"
    ) {
      res.status(409).json({ error: "Já existe uma conta com esse e-mail." });
      return;
    }
    throw error;
  }

  await createSession(user.id, res);
  res.status(201).json(RegisterResponse.parse(toPublicUser(user)));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email))
    .limit(1);

  const passwordMatches = user
    ? await verifyPassword(parsed.data.password, user.passwordHash)
    : (await hashPassword(parsed.data.password), false);

  if (!user || !passwordMatches || !user.isActive) {
    res.status(401).json({ error: "E-mail, senha ou conta indisponível." });
    return;
  }

  await createSession(user.id, res);
  res.json(LoginResponse.parse(toPublicUser(user)));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const token = req.cookies?.expense_session;
  if (typeof token === "string" && /^[a-f0-9]{64}$/.test(token)) {
    await revokeSession(token);
  }
  clearSessionCookie(res);
  res.sendStatus(204);
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const user = await getSessionUser(req, res);
  res.json(GetCurrentUserResponse.parse(user ? toPublicUser(user) : null));
});

export default router;
