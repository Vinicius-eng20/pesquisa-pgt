import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Route, Switch, Link, useLocation, Router as WouterRouter } from 'wouter';
import {
  useRegister, useLogin, useLogout, useGetCurrentUser, getGetCurrentUserQueryKey,
  useListExpenses, getListExpensesQueryKey, useCreateExpense, useUpdateExpense, useDeleteExpense,
  useGetDashboard, getGetDashboardQueryKey, useListCategories, getListCategoriesQueryKey,
  useCreateCategory, useUpdateCategory, useGetAdminSummary, getGetAdminSummaryQueryKey,
  useListUsers, getListUsersQueryKey, useUpdateUserStatus,
} from '@workspace/api-client-react';
import type { Account, Category, Expense, ExpenseInput } from '@workspace/api-client-react';
import {
  ArrowDownRight, ArrowRight, Coffee, LayoutDashboard, LogOut, Plus, Receipt, ShoppingBag, Tag, Users, Utensils,
  Wallet, X, Pencil, Trash2, CalendarDays, RefreshCw,
} from 'lucide-react';
import NotFound from '@/pages/not-found';
import '@/index.css';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } });
const currentMonth = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
};
const money = (cents: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format((cents || 0) / 100);
const dateLabel = (value: string) => new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(`${value.slice(0, 10)}T12:00:00`));
const monthLabel = (value: string) => {
  const [year, month] = value.split('-').map(Number);
  return new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(new Date(year, month - 1, 1));
};
const errorText = (error: unknown) => {
  if (error && typeof error === 'object' && 'message' in error && typeof error.message === 'string') return error.message;
  return 'Não foi possível concluir. Tente novamente.';
};
const initials = (name: string) => name.split(' ').slice(0, 2).map((part) => part[0]).join('').toUpperCase();
const categoryIcon = (name: string) => {
  const lower = name.toLowerCase();
  if (lower.includes('aliment') || lower.includes('mercado') || lower.includes('restaur')) return Utensils;
  if (lower.includes('transp')) return ArrowRight;
  if (lower.includes('casa') || lower.includes('morad')) return LayoutDashboard;
  if (lower.includes('compra')) return ShoppingBag;
  if (lower.includes('café')) return Coffee;
  return Receipt;
};

function Brand() {
  return <div className="brand"><span className="brand-mark"><Wallet size={19} strokeWidth={2.2} /></span><span>miúdo</span></div>;
}

function ErrorMessage({ children }: { children: ReactNode }) {
  return <div className="error-banner" role="alert">{children}</div>;
}

function LoadingCards() {
  return <div className="grid-metrics">{[1, 2, 3].map((n) => <div className="card skeleton loading-card" key={n} />)}</div>;
}

function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-icon"><Receipt size={21} /></div><h3 className="empty-title">{title}</h3><div>{description}</div>{action && <div style={{ marginTop: 17 }}>{action}</div>}</div>;
}

function Modal({ title, close, children }: { title: string; close: () => void; children: ReactNode }) {
  useEffect(() => {
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') close(); };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [close]);
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) close(); }}>
    <section className="modal" role="dialog" aria-modal="true" aria-label={title}>
      <div className="modal-head"><h2 className="modal-title">{title}</h2><button className="icon-button" aria-label="Fechar" onClick={close}><X size={17} /></button></div>
      {children}
    </section>
  </div>;
}

function MonthPicker({ month, setMonth }: { month: string; setMonth: (month: string) => void }) {
  return <label className="toolbar" style={{ gap: 7 }}><CalendarDays size={16} color="#718075" /><input aria-label="Filtrar por mês" className="month-select" type="month" value={month} onChange={(event) => setMonth(event.target.value)} data-testid="input-month" /></label>;
}

function Shell({ children, admin, user, onLogout, loggingOut }: { children: ReactNode; admin: boolean; user: { name: string; role: string }; onLogout: () => void; loggingOut: boolean }) {
  const [location] = useLocation();
  return <div className="app-shell">
    <aside className="sidebar">
      <Brand />
      <div className="nav-label">Seu espaço</div>
      <nav>
        <Link href="/dashboard" className={`nav-link ${location === '/dashboard' ? 'active' : ''}`} data-testid="link-dashboard"><LayoutDashboard size={18} />Visão geral</Link>
        <Link href="/expenses" className={`nav-link ${location === '/expenses' ? 'active' : ''}`} data-testid="link-expenses"><Receipt size={18} />Despesas</Link>
        {admin && <Link href="/admin" className={`nav-link ${location === '/admin' ? 'active' : ''}`} data-testid="link-admin"><Users size={18} />Administração</Link>}
      </nav>
      <div className="sidebar-spacer" />
      <div className="profile-mini"><div className="avatar">{initials(user.name)}</div><div className="profile-meta"><div className="profile-name">{user.name}</div><div className="profile-role">{admin ? 'Administrador' : 'Conta pessoal'}</div></div><button className="icon-button" style={{ background: 'transparent', color: '#d9e2d9', borderColor: 'rgba(255,255,255,.17)' }} onClick={onLogout} disabled={loggingOut} title="Sair" data-testid="button-logout"><LogOut size={16} /></button></div>
    </aside>
    <main className="main-area"><header className="topbar"><span className="topbar-note">Um jeito mais leve de cuidar do seu dinheiro.</span><div className="toolbar"><span className="avatar" style={{ width: 30, height: 30, fontSize: 11 }}>{initials(user.name)}</span><span style={{ fontSize: 12, fontWeight: 700 }}>{user.name.split(' ')[0]}</span></div></header>{children}</main>
  </div>;
}

function AuthPage({ onSuccess }: { onSuccess: () => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const cache = useQueryClient();
  const login = useLogin();
  const register = useRegister();
  const pending = login.isPending || register.isPending;
  const submit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    const done = (signedInUser: { id: number; name: string; email: string; role: 'admin' | 'user'; isActive: boolean }) => {
      cache.clear();
      cache.setQueryData(getGetCurrentUserQueryKey(), signedInUser);
      onSuccess();
    };
    if (mode === 'login') login.mutate({ data: { email, password } }, { onSuccess: done, onError: (err) => setError(errorText(err)) });
    else register.mutate({ data: { name, email, password } }, { onSuccess: done, onError: (err) => setError(errorText(err)) });
  };
  return <div className="auth-page">
    <section className="auth-art"><Brand /><div><div className="auth-statement">Seu dinheiro,<br />no <em>seu ritmo.</em></div><p className="auth-copy">Um espaço simples para acompanhar o que entra e sai — e terminar o mês com mais clareza.</p></div><div className="eyebrow" style={{ color: '#9fb2a4' }}>Organização que cabe na vida real</div></section>
    <section className="auth-main"><div className="auth-box">
      <div className="mobile-brand"><Brand /></div>
      <div className="auth-tabs"><button className={`auth-tab ${mode === 'login' ? 'active' : ''}`} onClick={() => { setMode('login'); setError(''); }} data-testid="tab-login">Entrar</button><button className={`auth-tab ${mode === 'register' ? 'active' : ''}`} onClick={() => { setMode('register'); setError(''); }} data-testid="tab-register">Criar conta</button></div>
      <h2>{mode === 'login' ? 'Que bom ter você de volta.' : 'Vamos começar.'}</h2><p>{mode === 'login' ? 'Entre para ver como está seu mês.' : 'Sua primeira conta será de administração.'}</p>
      <form className="form-stack auth-form" onSubmit={submit}>
        {mode === 'register' && <label className="form-label">Seu nome<input className="field" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" required maxLength={100} placeholder="Como podemos chamar você?" data-testid="input-name" /></label>}
        <label className="form-label">E-mail<input className="field" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required maxLength={254} placeholder="voce@email.com" data-testid="input-email" /></label>
        <label className="form-label">Senha<input className="field" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={mode === 'register' ? 10 : 1} maxLength={128} placeholder={mode === 'register' ? 'Pelo menos 10 caracteres' : 'Sua senha'} data-testid="input-password" /></label>
        {error && <ErrorMessage>{error}</ErrorMessage>}
        <button className="button button-primary" type="submit" disabled={pending} data-testid="button-auth-submit">{pending ? 'Só um instante…' : mode === 'login' ? <>Entrar na minha conta <ArrowRight size={16} /></> : <>Criar minha conta <ArrowRight size={16} /></>}</button>
      </form>
      <div className="auth-footer">Seus dados ficam protegidos pela sessão segura da sua conta.<br />Sem complicação, só clareza.</div>
    </div></section>
  </div>;
}

function DashboardPage({ name }: { name: string }) {
  const [month, setMonth] = useState(currentMonth);
  const dashboardQuery = useGetDashboard({ month });
  const dashboard = dashboardQuery.data;
  const categories = dashboard?.categoryTotals ?? [];
  return <div className="content">
    <div className="page-head"><div><div className="eyebrow">Seu resumo • {monthLabel(month)}</div><h1 className="page-title">Oi, {name.split(' ')[0]}.</h1><p className="page-subtitle">Aqui está um retrato tranquilo do seu mês.</p></div><MonthPicker month={month} setMonth={setMonth} /></div>
    {dashboardQuery.isLoading ? <LoadingCards /> : dashboardQuery.isError ? <ErrorMessage>Não conseguimos carregar seu resumo. <button className="button button-small button-secondary" onClick={() => dashboardQuery.refetch()}><RefreshCw size={13} /> Tentar de novo</button></ErrorMessage> : <>
      <div className="grid-metrics">
        <div className="card metric-card hero-metric"><div className="metric-label">Você gastou neste mês</div><div className="metric-value" data-testid="text-month-total">{money(dashboard?.totalCents ?? 0)}</div><div className="metric-foot"><ArrowDownRight size={15} /> {dashboard?.expenseCount ?? 0} lançamentos registrados</div></div>
        <div className="card metric-card"><div className="metric-label">Despesas registradas</div><div className="metric-value">{dashboard?.expenseCount ?? 0}</div><div className="metric-foot"><Receipt size={14} /> neste período</div></div>
        <div className="card metric-card"><div className="metric-label">Categorias usadas</div><div className="metric-value">{categories.length}</div><div className="metric-foot"><Tag size={14} /> com gastos no mês</div></div>
      </div>
      <div className="dashboard-grid">
        <section className="card section-card">
          <div className="section-heading"><div><h2 className="section-title">Para onde foi</h2><div className="section-caption">Seus gastos por categoria</div></div><Link href="/expenses" className="button button-quiet button-small">Ver despesas <ArrowRight size={14} /></Link></div>
          {categories.length ? categories.map((category) => <div className="category-row" key={category.categoryId}><div className="category-info"><span className="category-name">{category.categoryName}</span><span className="category-total">{money(category.totalCents)}</span></div><div className="progress-track"><div className="progress-fill" style={{ width: `${Math.max(3, Math.min(100, dashboard?.totalCents ? category.totalCents / dashboard.totalCents * 100 : 0))}%` }} /></div></div>) : <EmptyState title="Ainda sem categorias usadas" description="Quando registrar uma despesa, ela aparece aqui." />}
        </section>
        <section className="card section-card">
          <div className="section-heading"><div><h2 className="section-title">Recentes</h2><div className="section-caption">Seus últimos registros</div></div><Link href="/expenses" className="icon-button" aria-label="Ver despesas"><ArrowRight size={16} /></Link></div>
          {dashboard?.recentExpenses?.length ? dashboard.recentExpenses.slice(0, 5).map((expense) => <ExpenseRow expense={expense} key={expense.id} />) : <EmptyState title="Tudo começa por aqui" description="Adicione sua primeira despesa para ver o movimento do mês." action={<Link href="/expenses" className="button button-primary button-small"><Plus size={14} /> Registrar despesa</Link>} />}
        </section>
      </div>
    </>}
  </div>;
}

function ExpenseRow({ expense, action }: { expense: Expense; action?: ReactNode }) {
  const Icon = categoryIcon(expense.categoryName);
  return <div className="list-row"><div className="list-icon"><Icon size={17} /></div><div className="row-main"><div className="row-title">{expense.description}</div><div className="row-meta">{expense.categoryName} · {dateLabel(expense.spentAt)}</div></div><div className="row-amount">{money(expense.amountCents)}</div>{action}</div>;
}

function ExpenseModal({ expense, close, categories }: { expense?: Expense; close: () => void; categories: Category[] }) {
  const cache = useQueryClient();
  const create = useCreateExpense();
  const update = useUpdateExpense();
  const [categoryId, setCategoryId] = useState(String(expense?.categoryId ?? categories.find((c) => c.isActive)?.id ?? ''));
  const [amount, setAmount] = useState(expense ? (expense.amountCents / 100).toFixed(2).replace('.', ',') : '');
  const [spentAt, setSpentAt] = useState(expense?.spentAt.slice(0, 10) ?? new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState(expense?.description ?? '');
  const [error, setError] = useState('');
  const pending = create.isPending || update.isPending;
  const submit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    const normalizedAmount = amount.includes(',') ? amount.replace(/\./g, '').replace(',', '.') : amount;
    const cents = Math.round(Number(normalizedAmount) * 100);
    const data: ExpenseInput = { categoryId: Number(categoryId), amountCents: cents, spentAt, description: description.trim() };
    const done = () => {
      cache.invalidateQueries({ queryKey: ['/api/expenses'] });
      cache.invalidateQueries({ queryKey: ['/api/dashboard'] });
      close();
    };
    if (!Number.isFinite(cents) || cents < 1 || !categoryId) { setError('Confira o valor e escolha uma categoria ativa.'); return; }
    if (expense) update.mutate({ expenseId: expense.id, data }, { onSuccess: done, onError: (err) => setError(errorText(err)) });
    else create.mutate({ data }, { onSuccess: done, onError: (err) => setError(errorText(err)) });
  };
  return <Modal title={expense ? 'Editar despesa' : 'Nova despesa'} close={close}><form className="form-stack" onSubmit={submit}>
    <label className="form-label">O que foi?<input className="field" value={description} onChange={(e) => setDescription(e.target.value)} required maxLength={240} placeholder="Ex.: almoço de terça" data-testid="input-expense-description" /></label>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
      <label className="form-label">Valor (R$)<input className="field" value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" required placeholder="0,00" data-testid="input-expense-amount" /></label>
      <label className="form-label">Data<input className="field" type="date" value={spentAt} onChange={(e) => setSpentAt(e.target.value)} required data-testid="input-expense-date" /></label>
    </div>
    <label className="form-label">Categoria<select className="select-field" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} required data-testid="select-expense-category"><option value="">Escolha uma categoria</option>{categories.filter((c) => c.isActive || c.id === expense?.categoryId).map((c) => <option value={c.id} key={c.id}>{c.name}{!c.isActive ? ' (inativa)' : ''}</option>)}</select></label>
    {error && <ErrorMessage>{error}</ErrorMessage>}
    <div className="form-actions"><button type="button" className="button button-secondary" onClick={close}>Cancelar</button><button className="button button-primary" type="submit" disabled={pending} data-testid="button-save-expense">{pending ? 'Salvando…' : expense ? 'Salvar alterações' : 'Adicionar despesa'}</button></div>
  </form></Modal>;
}

function ExpensesPage() {
  const [month, setMonth] = useState(currentMonth);
  const [categoryId, setCategoryId] = useState('');
  const [editing, setEditing] = useState<Expense | null | 'new'>(null);
  const cache = useQueryClient();
  const params = useMemo(() => ({ month, ...(categoryId ? { categoryId: Number(categoryId) } : {}) }), [month, categoryId]);
  const expensesQuery = useListExpenses(params);
  const categoriesQuery = useListCategories();
  const remove = useDeleteExpense();
  const [error, setError] = useState('');
  const expenses = expensesQuery.data ?? [];
  const categories = categoriesQuery.data ?? [];
  const deleteExpense = (expense: Expense) => {
    if (!window.confirm(`Excluir “${expense.description}”? Essa ação não pode ser desfeita.`)) return;
    setError('');
    remove.mutate({ expenseId: expense.id }, { onSuccess: () => { cache.invalidateQueries({ queryKey: getListExpensesQueryKey() }); cache.invalidateQueries({ queryKey: ['/api/dashboard'] }); }, onError: (err) => setError(errorText(err)) });
  };
  return <div className="content">
    <div className="page-head"><div><div className="eyebrow">Movimento do seu dinheiro</div><h1 className="page-title">Despesas</h1><p className="page-subtitle">Cada registro deixa o mês um pouco mais claro.</p></div><button className="button button-primary" onClick={() => setEditing('new')} data-testid="button-add-expense"><Plus size={17} /> Nova despesa</button></div>
    <section className="card section-card">
      <div className="section-heading"><div><h2 className="section-title">{monthLabel(month)}</h2><div className="section-caption">{expenses.length} {expenses.length === 1 ? 'despesa' : 'despesas'} encontradas</div></div>
        <div className="toolbar"><MonthPicker month={month} setMonth={setMonth} /><select className="select-field" aria-label="Filtrar por categoria" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} data-testid="select-category-filter"><option value="">Todas as categorias</option>{categories.map((category) => <option value={category.id} key={category.id}>{category.name}</option>)}</select></div></div>
      {error && <ErrorMessage>{error}</ErrorMessage>}
      {expensesQuery.isLoading || categoriesQuery.isLoading ? <div className="skeleton" style={{ height: 240 }} /> : expensesQuery.isError ? <EmptyState title="Não carregamos suas despesas" description="Confira sua conexão e tente novamente." action={<button className="button button-secondary button-small" onClick={() => expensesQuery.refetch()}><RefreshCw size={14} /> Tentar de novo</button>} /> : expenses.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Descrição</th><th>Categoria</th><th>Data</th><th>Valor</th><th></th></tr></thead><tbody>{expenses.map((expense) => <tr key={expense.id} data-testid={`row-expense-${expense.id}`}><td style={{ fontWeight: 700 }}>{expense.description}</td><td>{expense.categoryName}</td><td>{dateLabel(expense.spentAt)}</td><td style={{ fontWeight: 700 }}>{money(expense.amountCents)}</td><td><div className="toolbar" style={{ justifyContent: 'flex-end' }}><button className="icon-button" aria-label={`Editar ${expense.description}`} onClick={() => setEditing(expense)} data-testid={`button-edit-expense-${expense.id}`}><Pencil size={15} /></button><button className="icon-button" aria-label={`Excluir ${expense.description}`} onClick={() => deleteExpense(expense)} disabled={remove.isPending} data-testid={`button-delete-expense-${expense.id}`}><Trash2 size={15} /></button></div></td></tr>)}</tbody></table></div> : <EmptyState title="Nenhuma despesa neste mês" description="Registre seus gastos para acompanhar para onde o dinheiro está indo." action={<button className="button button-primary button-small" onClick={() => setEditing('new')}><Plus size={14} /> Registrar primeira despesa</button>} />}
    </section>
    {editing && <ExpenseModal expense={editing === 'new' ? undefined : editing} close={() => setEditing(null)} categories={categories} />}
  </div>;
}

function AdminPage() {
  const [month, setMonth] = useState(currentMonth);
  const [newCategory, setNewCategory] = useState('');
  const [editing, setEditing] = useState<Category | null>(null);
  const [categoryName, setCategoryName] = useState('');
  const [error, setError] = useState('');
  const cache = useQueryClient();
  const summaryQuery = useGetAdminSummary({ month });
  const categoriesQuery = useListCategories();
  const usersQuery = useListUsers();
  const createCategory = useCreateCategory();
  const updateCategory = useUpdateCategory();
  const updateUser = useUpdateUserStatus();
  const refresh = () => {
    cache.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
    cache.invalidateQueries({ queryKey: getListUsersQueryKey() });
    cache.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
  };
  const saveCategory = (event: FormEvent) => {
    event.preventDefault(); setError('');
    const done = () => { setNewCategory(''); refresh(); };
    createCategory.mutate({ data: { name: newCategory.trim() } }, { onSuccess: done, onError: (err) => setError(errorText(err)) });
  };
  const saveEditCategory = (event: FormEvent) => {
    event.preventDefault(); if (!editing) return;
    updateCategory.mutate({ categoryId: editing.id, data: { name: categoryName.trim() } }, { onSuccess: () => { setEditing(null); refresh(); }, onError: (err) => setError(errorText(err)) });
  };
  const toggleCategory = (category: Category) => {
    updateCategory.mutate({ categoryId: category.id, data: { isActive: !category.isActive } }, { onSuccess: refresh, onError: (err) => setError(errorText(err)) });
  };
  const toggleUser = (user: Account) => {
    if (!user.isActive && !window.confirm(`Ativar o acesso de ${user.name}?`)) return;
    if (user.isActive && !window.confirm(`Desativar a conta de ${user.name}?`)) return;
    updateUser.mutate({ userId: user.id, data: { isActive: !user.isActive } }, { onSuccess: refresh, onError: (err) => setError(errorText(err)) });
  };
  const summary = summaryQuery.data;
  const categories = categoriesQuery.data ?? [];
  const users = usersQuery.data ?? [];
  const busy = summaryQuery.isLoading || categoriesQuery.isLoading || usersQuery.isLoading;
  return <div className="content">
    <div className="page-head"><div><div className="eyebrow">Visão geral da comunidade</div><h1 className="page-title">Administração</h1><p className="page-subtitle">Cuide das categorias e dos acessos em um só lugar.</p></div><MonthPicker month={month} setMonth={setMonth} /></div>
    {error && <ErrorMessage>{error}</ErrorMessage>}
    {busy ? <LoadingCards /> : summaryQuery.isError || categoriesQuery.isError || usersQuery.isError ? <ErrorMessage>Não foi possível carregar os dados administrativos. <button className="button button-small button-secondary" onClick={() => { summaryQuery.refetch(); categoriesQuery.refetch(); usersQuery.refetch(); }}><RefreshCw size={13} /> Tentar novamente</button></ErrorMessage> : <>
      <div className="grid-metrics">
        <div className="card metric-card hero-metric"><div className="metric-label">Gastos de todas as contas</div><div className="metric-value">{money(summary?.totalCents ?? 0)}</div><div className="metric-foot"><ArrowDownRight size={15} /> {summary?.expenseCount ?? 0} lançamentos em {monthLabel(month)}</div></div>
        <div className="card metric-card"><div className="metric-label">Contas ativas</div><div className="metric-value">{summary?.activeUsers ?? 0}</div><div className="metric-foot"><Users size={14} /> de {summary?.totalUsers ?? 0} cadastradas</div></div>
        <div className="card metric-card"><div className="metric-label">Categorias</div><div className="metric-value">{categories.length}</div><div className="metric-foot"><Tag size={14} /> {categories.filter((c) => c.isActive).length} ativas</div></div>
      </div>
      <div className="dashboard-grid" style={{ alignItems: 'start' }}>
        <section className="card section-card"><div className="section-heading"><div><h2 className="section-title">Categorias</h2><div className="section-caption">Disponíveis para os registros de despesas</div></div></div>
          <form className="toolbar" onSubmit={saveCategory} style={{ marginBottom: 16 }}><input className="field" style={{ flex: 1, minWidth: 130 }} value={newCategory} onChange={(e) => setNewCategory(e.target.value)} placeholder="Nome da categoria" required maxLength={80} data-testid="input-new-category" /><button type="submit" className="button button-primary button-small" disabled={createCategory.isPending}><Plus size={15} /> Adicionar</button></form>
          {categories.length ? categories.map((category) => <div className="list-row" key={category.id}><div className="list-icon"><Tag size={16} /></div><div className="row-main"><div className="row-title">{category.name}</div><div className="row-meta">{category.isActive ? 'Visível para novas despesas' : 'Não disponível para novos registros'}</div></div><span className={`status-pill ${category.isActive ? 'status-on' : 'status-off'}`}>{category.isActive ? 'Ativa' : 'Inativa'}</span><button className="icon-button" aria-label={`Renomear ${category.name}`} onClick={() => { setEditing(category); setCategoryName(category.name); }}><Pencil size={14} /></button><button className="button button-secondary button-small" onClick={() => toggleCategory(category)} disabled={updateCategory.isPending}>{category.isActive ? 'Desativar' : 'Ativar'}</button></div>) : <EmptyState title="Sem categorias ainda" description="Adicione a primeira categoria acima." />}
        </section>
        <section className="card section-card"><div className="section-heading"><div><h2 className="section-title">Contas</h2><div className="section-caption">Acesso das pessoas cadastradas</div></div></div>
          {users.length ? users.map((user) => <div className="list-row" key={user.id}><div className="avatar">{initials(user.name)}</div><div className="row-main"><div className="row-title">{user.name}</div><div className="row-meta">{user.email} · {user.role === 'admin' ? 'Admin' : 'Pessoa usuária'}</div></div><span className={`status-pill ${user.isActive ? 'status-on' : 'status-off'}`}>{user.isActive ? 'Ativa' : 'Inativa'}</span>{user.role !== 'admin' && <button className="button button-secondary button-small" onClick={() => toggleUser(user)} disabled={updateUser.isPending}>{user.isActive ? 'Desativar' : 'Ativar'}</button>}</div>) : <EmptyState title="Nenhuma conta cadastrada" description="As novas contas aparecerão aqui." />}
        </section>
      </div>
      <section className="card section-card" style={{ marginTop: 18 }}><div className="section-heading"><div><h2 className="section-title">Gastos por categoria</h2><div className="section-caption">{monthLabel(month)} · todas as contas</div></div></div>
        {summary?.categoryTotals?.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Categoria</th><th>Lançamentos</th><th>Total no mês</th></tr></thead><tbody>{summary.categoryTotals.map((item) => <tr key={item.categoryId}><td style={{ fontWeight: 700 }}>{item.categoryName}</td><td>{item.count}</td><td style={{ fontWeight: 700 }}>{money(item.totalCents)}</td></tr>)}</tbody></table></div> : <EmptyState title="Nenhum gasto neste período" description="Os totais aparecem quando houver despesas registradas." />}</section>
    </>}
    {editing && <Modal title="Renomear categoria" close={() => setEditing(null)}><form className="form-stack" onSubmit={saveEditCategory}><label className="form-label">Nome<input className="field" value={categoryName} onChange={(e) => setCategoryName(e.target.value)} required maxLength={80} /></label><div className="form-actions"><button type="button" className="button button-secondary" onClick={() => setEditing(null)}>Cancelar</button><button className="button button-primary" disabled={updateCategory.isPending}>Salvar</button></div></form></Modal>}
  </div>;
}

function AuthenticatedApp() {
  const [location, setLocation] = useLocation();
  const cache = useQueryClient();
  const current = useGetCurrentUser();
  const logout = useLogout();
  const user = current.data;
  useEffect(() => {
    if (user && location === '/') setLocation('/dashboard');
    if (!user && current.isError && location !== '/') setLocation('/');
  }, [user, current.isError, location, setLocation]);
  const handleLogout = () => logout.mutate(undefined, { onSettled: () => { cache.clear(); setLocation('/'); } });
  if (location === '/' && (current.isLoading || current.isFetching) && !current.isError && !user) return <div className="auth-page"><div className="auth-main"><div className="skeleton" style={{ width: 340, height: 360 }} /></div></div>;
  if (current.isLoading || current.isFetching && !user) return <div className="auth-page"><div className="auth-main"><div className="skeleton" style={{ width: 340, height: 360 }} /></div></div>;
  if (!user) return <AuthPage onSuccess={() => { cache.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() }); setLocation('/dashboard'); }} />;
  if (!user.isActive) return <div className="auth-page"><section className="auth-main"><div className="auth-box"><Brand /><h2 style={{ marginTop: 24 }}>Conta desativada</h2><p>O acesso desta conta está pausado. Fale com a pessoa administradora.</p><button className="button button-primary" style={{ marginTop: 24 }} onClick={handleLogout}>Sair da conta</button></div></section></div>;
  const admin = user.role === 'admin';
  return <Shell admin={admin} user={user} onLogout={handleLogout} loggingOut={logout.isPending}>
    <Switch><Route path="/dashboard"><DashboardPage name={user.name} /></Route><Route path="/expenses"><ExpensesPage /></Route><Route path="/admin">{admin ? <AdminPage /> : <div className="content"><EmptyState title="Acesso restrito" description="Esta área é exclusiva para administradores." /></div>}</Route><Route component={NotFound} /></Switch>
  </Shell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AuthenticatedApp /></WouterRouter></QueryClientProvider>;
}
export default App;
