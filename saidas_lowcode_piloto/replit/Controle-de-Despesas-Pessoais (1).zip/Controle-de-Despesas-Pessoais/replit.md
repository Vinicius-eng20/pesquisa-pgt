# Controle de Despesas

Site responsivo de despesas pessoais com contas próprias, banco persistente, categorias e área administrativa.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/controle-despesas` — aplicação web
- `artifacts/api-server/src/routes` — API de autenticação, despesas e administração
- `lib/api-spec/openapi.yaml` — contrato da API; gere os hooks com `pnpm --filter @workspace/api-spec run codegen`
- `lib/db/src/schema` — tabelas persistidas no PostgreSQL

## Architecture decisions

- A primeira conta registrada recebe o papel de administradora; as seguintes recebem o papel de usuária.
- Sessões são opacas, persistidas no banco e armazenadas em cookie HTTP-only; senhas são derivadas com scrypt.
- Desativar uma conta encerra as sessões existentes, sem apagar o histórico de gastos.
- Gastos usam valores em centavos inteiros para evitar erros de arredondamento.

## Product

Usuários registram, editam, filtram e acompanham seus próprios gastos mensais. A administração gerencia categorias e contas e vê totais agregados de toda a comunidade.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
